import UIKit

var firstName: String = "Zhanel"
var lastName: String = "Amanzhol"
var age: Int
var birthYear: Int = 2005
var isStudent: Bool = true
var height: Double = 1.61
var weight: Double = 54

let currentYear: Int = 2025
age = currentYear - birthYear

var studentStatus: String = isStudent ? "a student" : "not a student"

var hobbies: String = "watching anime, k-drama, movies, reading books, drawing"
var numberOfHobbies: Int = 5
var favouriteNumber: Int = 28
var isHobbyCreative: Bool = true
var favouriteColor: String = "blue"
var favouriteDrink: String = "qymyz"

var lifeStory: String = "Hi! My name is \(firstName) \(lastName). \nI was born in \(birthYear) and turned \(age) this summer. I am currently \(studentStatus). \nMy height: \(height) m, weight: \(weight) kg. \nMy favourite color is \(favouriteColor) and drink is \(favouriteDrink).\nI think that \(favouriteNumber) is special number for me, since I was born on the 28th of August.\nI have \(numberOfHobbies) hobbies: \(hobbies).\n"

var futureGoal: String = "reborn as a cat 🐈"
print(lifeStory + "In the future (next life), I want to \(futureGoal).")
